using System.Collections.Generic;
using System.IO;
using Alife.Foundation;

namespace presents.Video;

public static class TextZh
{
    // 繁转简映射表：whisper/SenseVoice/在线转写对中文都常输出繁体。
    // 表随插件分发在 PluginData/presents.Video/textzh.tsv，首次使用时懒加载；
    // Windows LCMapString 无繁体语言包时静默空转，所以自带映射表。
    private static Dictionary<char, char>? map;
    private static readonly object gate = new();
    private static bool tried;

    private static Dictionary<char, char>? Load()
    {
        lock (gate)
        {
            if (map != null || tried) return map;
            tried = true;
            try
            {
                string path = Path.Combine(AlifePath.StorageFolderPath, "PluginData", "presents.Video", "textzh.tsv");
                var d = new Dictionary<char, char>(4096);
                foreach (string line in File.ReadAllLines(path))
                {
                    if (line.Length >= 3)
                    {
                        if (line[1] == '\t')
                        {
                            d[line[0]] = line[2];
                        }
                    }
                }
                map = d;
            }
            catch
            {
                map = new Dictionary<char, char>();   // 表缺失：降级为不转换
            }
            return map;
        }
    }

    private static readonly string TradMarkers =
        "們這時說個來對時間會國後開關裡麼歲點讓進遠運過還現實發應該當學覺聽寫讀書體驗經網視頻戲劇場聲貓馬鳥雞龍鳳飛雲電風雨雪霧氣溫濕測試驗證據戰爭鬥機內關係聯繫繼續費員廠區冊單據題標園藝醫藥廳曆歷鐘錶錄製訂閱閱讀壓號碼賽車輛隊額頭";

    /// <summary>繁体转简体：检测到 ≥2 个繁体特征字才转换，简体原文零改动。</summary>
    public static string MaybeSimplify(string text)
    {
        if (string.IsNullOrWhiteSpace(text)) return text;

        var d = Load();
        if (d == null || d.Count == 0) return text;

        int markers = 0;
        foreach (char c in text)
        {
            if (d.ContainsKey(c))
            {
                markers++;
                if (markers >= 2) break;
            }
        }

        if (markers < 2) return text;

        var sb = new System.Text.StringBuilder(text.Length);
        foreach (char c in text)
            sb.Append(d.TryGetValue(c, out char s) ? s : c);
        return sb.ToString();
    }
}
